def ifparse(formula):
    formula = 'if(oldposition,2*decay_linear(rank(volume)*(ts_sum(close,5)/5)*(vwap-close)/(high-low),5),decay_linear(rank(volume)*(ts_sum(close,5)/5)*(vwap-close)/(high-low),5))'
    level = [0 for i in range(len(formula))]
    current = 0
    for i in range(len(formula)):
        if (formula[i] == '('): 
            current += 1
            level[i] = current 
        elif (formula[i] == ')'):
            level[i] = current
            current -= 1
    m = max(level) - 1
    hierachy = list()
    while m > 0:
        p = list()
        i = 0
        while i < len(formula):
            if (level[i] == m):
                j = i + 1
                while level[j] != m: j += 1
                p.append(formula[i + 1:j])
                i = j + 1
            else:
                i += 1
        p = list(set(p))
        hierachy.insert(0, p)
        m -= 1
    h2 = hierachy
    m = max(level) - 1
    relation = dict()
    count = 0
    while m > 0:
        to_replace = hierachy[m - 1]
        for string in to_replace:
            relation['s' + str(count)] = string
            count += 1
        t = m - 2
        while t >= 0:
            for r in relation.keys():
                for i in range(len(hierachy[t])):
                    hierachy[t][i] = hierachy[t][i].replace(relation[r], r)
                    #s = s.replace(relation[r], r)
            t -= 1
        m -= 1
    print(hierachy)
    print(relation)
    r_list = sorted(relation.keys())
    global_interest = list()
    for i in range(len(r_list)):
        if (relation[r_list[i]].count(',') > 1):
            interest = relation[r_list[i]].split(',')[1:]
            for k in range(len(interest)):
                j = i - 1
                while j >= 0:
                    interest[k] = interest[k].replace(r_list[j], relation[r_list[j]])
                    j -= 1
            global_interest.extend(interest)
    relation_n = dict()
    count = 0
    for i in range(len(global_interest)):
        if not 'oldposition' in global_interest[i]:
            relation_n['s' + str(count)] = global_interest[i]
            count += 1
    for i in relation_n.keys():
        formula = formula.replace(relation_n[i], i)
    print(formula)
    return formula, relation_n

